function ealertintrojs(){
    alert('krima')
    document.body.style.backgroundColor="green"
}
function econfirmintrojs(){
    confirm('krima')
    document.body.style.backgroundColor="red"
}
function epromptintrojs(){
    prompt('krima')
    document.body.style.backgroundColor="yellow"
}