$(document).ready(function(){
    $("#d3").click(function(){
        alert("show");
        $("#d1").show(5000);
        
    });
});
$(document).ready(function(){
    $("#d4").click(function(){
        alert("size increase");
        $("#d1").width(200);
        $("#d1").height(200);
    });
});
$(document).ready(function(){
    $("#d5").click(function(){
        alert("size decrease");
        $("#d1").width(50);
        $("#d1").height(50);
    });
});
$(document).ready(function(){
    $("#d2").click(function(){
        alert("hide");
        $("#d1").hide(5000);
        
    });
});
$(document).ready(function(){
    $("#d1").click(function(){
        alert("hello");
    });
    $("#d4").click(function(){
        var MDH=parseInt($("#d1").css("height"));
        if(MDH<=150)
        {
            MDH+=10;
            $("#d1").css("height",MDH);
            $("#d1").css("width",MDH);
        }
        else{
            alert("More than 150px is not possible");
        }
    })

    $("#d5").click(function(){
        var MDH=parseInt($("#d1").css("height"));
        if(MDH<=20)
        {
            MDH-=10;
            $("#d1").css("height",MDH);
            $("#d1").css("width",MDH);
        }
        else{
            alert("less than 20px is not possible");
        }
    })
    $("#d3").attr("disabled",true);
    $("#d2").click(function(){
        if(confirm("are you sure...?"))
        {
            $("#d1").hide(3000);
            $(this).attr("disabled",true);
            $("#d3").attr("disabled",false);
            
        }
    })
    $("#d3").click(function(){
        if(confirm("are you sure...?"))
        {
            $("#d1").show(3000);
            $(this).attr("disabled",true);
            $("#d3").attr("disabled",false);
            
        }
    })
   
      

})